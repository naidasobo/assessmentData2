log_file = open(r"hw5/um-server-01.txt") # this opens the file to the Python env
#opens the server file

def sales_reports(log_file): # Function definition
    for line in log_file: # For loop iterates the txt file line by line
        line = line.rstrip() # Strips trailing white space from the line text
        day = line[0:3] # slices line from the 0-2 positions in the line
        if day == "Tue": # Conditional for finding a day in the line
            print(line) # If tuesday print the entire line


sales_reports(log_file) # Function call passing the file we defined as a parameter
